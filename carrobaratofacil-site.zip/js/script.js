
function calcularFinanciamento() {
  const valor = parseFloat(document.getElementById("valor").value);
  const entrada = parseFloat(document.getElementById("entrada").value);
  const parcelas = parseInt(document.getElementById("parcelas").value);
  const juros = parseFloat(document.getElementById("juros").value) / 100;

  if (isNaN(valor) || isNaN(entrada) || isNaN(parcelas) || isNaN(juros)) {
    alert("Preencha todos os campos corretamente!");
    return;
  }

  const saldo = valor - entrada;
  const parcela = (saldo * juros) / (1 - Math.pow(1 + juros, -parcelas));
  const total = parcela * parcelas;

  document.getElementById("resultado").innerText =
    `Parcela aproximada: R$ ${parcela.toFixed(2)} | Total: R$ ${total.toFixed(2)}`;
}
